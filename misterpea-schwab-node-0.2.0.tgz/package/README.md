# Schwab Interface for Node.js 💵

A Node.js wrapper for Schwab's Market Data API with OAuth, accounts, quotes, price history, market hours, movers, options helpers, and streaming data.

![Node](https://img.shields.io/badge/node-%3E%3D20.6.0-brightgreen)
![License](https://img.shields.io/badge/license-MIT-blue)

## Installation and Setup
<details>
  <summary>View Installation and Setup</summary>

  ## Installation


```bash
npm install @misterpea/schwab-node
```

<br />

## Setup

__1.__ Visit `https://developer.schwab.com`, create an account, and register your app.

__2.__ Add an `.env` file to your project root 
   * Use the exact environment variable names below.
   * The redirect URI *must* be a localhost HTTPS address with an explicit port.

```bash
SCHWAB_CLIENT_SECRET=A1B2C3D4E5F6G7H8
SCHWAB_CLIENT_ID=ABCDEFGHIJKLMNOPQRSTUVWXZY123456
SCHWAB_REDIRECT_URI=https://127.0.0.1:PORT
```

__3.__ Generate local certs for the OAuth callback:

```bash
npx schwab-node-certs --callback https://my-redirect:port
```

The cert script prefers `mkcert` when available on your system and falls back to `openssl` if `mkcert` is not installed.

</details>


## Import Paths

### Import from the package root: Recommended for most users

```typescript
import {
  getPriceHistory,
  getQuote,
  getOptionChain,
  getOptionExpirations,
  getAtmOptionData,
  greekFilter,
  getMovers,
  getMarketHours,
  getAccountNumbers,
  getAccounts,
  getUserPreference,
  SchwabAuth,
} from "@misterpea/schwab-node";
```

<details>
<summary>Import from namespace subpaths if you need a mental demarcation:</summary>

```typescript
import { getQuote, getPriceHistory } from "@misterpea/schwab-node/market-data";
import { getOptionChain, greekFilter } from "@misterpea/schwab-node/derivatives";
import { getAccounts } from "@misterpea/schwab-node/account";
import { SchwabAuth } from "@misterpea/schwab-node/oauth/schwabAuth";
```
</details>

## API

| Export                         | Description                                           | Returns                                                                             |
| ------------------------------ | ----------------------------------------------------- | ----------------------------------------------------------------------------------- |
| `getQuote(config)`             | Quote and/or fundamentals for one or more symbols     | `Promise<GetQuotesResponse>`                                                        |
| `getPriceHistory(config)`      | Price history candles for a symbol                    | `Promise<GetPriceHistoryResponse \| undefined>`                                     |
| `getMovers(config)`            | Top 10 movers for an index                            | `Promise<ScreenersResponse>`                                                        |
| `getMarketHours(config)`       | Market hours for one or more markets                  | `Promise<MarketHoursRtn[]>`                                                         |
| `getOptionChain(config)`       | Option chain keyed by expiration and strike           | `Promise<GetOptionChainReturn \| undefined>`                                        |
| `getOptionExpirations(config)` | Available expirations for a symbol                    | `Promise<OptionExpirationReturn \| undefined>`                                      |
| `getAtmOptionData(config)`     | ATM options in an inclusive DTE window                | `Promise<GetAtmOptionReturn \| undefined>`                                          |
| `greekFilter(config)`          | Options filtered by DTE and Greek ranges              | `Promise<GreekFilterReturn>`                                                        |
| `getAccounts()`                | Info on accounts, including balances and buying power | `Promise<AccountsResponse>`                                                         |
| `getAccountNumbers()`          | Account numbers and their encrypted values            | `Promise<UserAccountNumbers>`                                                       |
| `getUserPreference()`          | Accounts and streamer info                            | `Promise<UserPreferenceResponse>`                                                   |
| `SchwabAuth`                   | Explicit OAuth client                                 | `SchwabAuth`                                                                        |
| `auth.getAuth()`               | Valid token, refreshed or acquired as needed          | `Promise<{ access_token: string; refresh_token: string; expires_in: number; ... }>` |

Config validation notes:

- `getPriceHistory()`, `getOptionChain()`, `getOptionExpirations()`, and `getAtmOptionData()` validate request input before calling Schwab.
- When those request objects fail validation, the function logs a validation tree and returns `undefined`.
- Successful responses are parsed with Zod before being returned.

## Route Changes

The package now uses kebab-case namespace paths such as `market-data`.

Legacy import routes still resolve for compatibility, but they emit a one-time `DeprecationWarning` telling callers which path to move to.

| Legacy import                                     | Use instead                              |
| ------------------------------------------------- | ---------------------------------------- |
| `@misterpea/schwab-node/marketData/quotes`        | `@misterpea/schwab-node/market-data`     |
| `@misterpea/schwab-node/marketData/highLevelData` | `@misterpea/schwab-node/market-data`     |
| `@misterpea/schwab-node/marketData/derivatives`   | `@misterpea/schwab-node/derivatives`     |
| `@misterpea/schwab-node/marketData/request`       | `@misterpea/schwab-node/scripts/request` |

Compatibility notes for those legacy routes:

- `marketData/quotes` keeps the old array-wrapped quote and price-history envelope.
- `marketData/highLevelData` keeps the old movers envelope of `{ screeners: [...] }[]`.
- `marketData/derivatives` keeps the old array-wrapped option-chain shape and maps ATM output back to `day_of_week`.

## Examples - `market-data`

### `getQuote()` - Quote and/or fundamentals for one or more symbols

```typescript
import { getQuote, GetQuoteRequest } from "@misterpea/schwab-node";

const config: GetQuoteRequest = { 
  symbols: 'AAPL, NVDA',
  fields: 'fundamental'
};

const quote = await getQuote(config);
```
<details>
<summary>Example response shape:</summary>

```typescript
{
  AAPL: {
    assetMainType: 'EQUITY',
    assetSubType: 'COE',
    ssid: 1973757747,
    symbol: 'AAPL',
    fundamental: {
      avg10DaysVolume: 41586451,
      avg1YearVolume: 53913953,
      divAmount: 1.04,
      divFreq: 4,
      divPayAmount: 0.26,
      divYield: 0.39616,
      eps: 7.46,
      fundLeverageFactor: 0,
      lastEarningsDate: '2026-01-29T00:00:00Z',
      peRatio: 33.01258,
      sharesOutstanding: 14681140000
    }
  },
  NVDA: {
    assetMainType: 'EQUITY',
    assetSubType: 'COE',
    ssid: 382397811,
    symbol: 'NVDA',
    fundamental: {
      avg10DaysVolume: 213969277,
      avg1YearVolume: 203975414,
      divAmount: 0.04,
      divFreq: 4,
      divPayAmount: 0.01,
      divYield: 0.02185,
      eps: 4.9,
      fundLeverageFactor: 0,
      lastEarningsDate: '2026-02-25T00:00:00Z',
      peRatio: 37.41633,
      sharesOutstanding: 24296000000
    }
  }
}
```
</details>

### `getPriceHistory()` - Price history candles for a symbol

```typescript
import { getPriceHistory, GetPriceHistoryRequest } from "@misterpea/schwab-node";

const config: GetPriceHistoryRequest = { 
    symbol: 'GILD',
    periodType: 'month',
    period: 1,
    frequencyType: 'daily',
    frequency: 1
  };

  const priceHistory = await getPriceHistory(config);
});
```

<details>
  <summary>Example response shape:</summary>

```typescript
{
  symbol: 'GILD',
  empty: false,
  candles: [
    {
      open: 146.5,
      high: 150.5,
      low: 145.87,
      close: 149.37,
      volume: 9143045,
      datetime: 1770271200000
    },
    {
      open: 149.69,
      high: 153.13,
      low: 148.7082,
      close: 152.5,
      volume: 8510037,
      datetime: 1770357600000
    },
    // ...
    {
      open: 148.92,
      high: 148.92,
      low: 146.1,
      close: 148.22,
      volume: 6925216,
      datetime: 1772604000000
    },
    {
      open: 146.32,
      high: 146.7531,
      low: 143.345,
      close: 145.14,
      volume: 6944156,
      datetime: 1772690400000
    }
  ]
}
```

</details>

### `getMovers()` - Top 10 movers for a specific index sorted by category

```typescript
import { getMovers, GetMoversConfig } from "@misterpea/schwab-node";

const config: GetMoversConfig = {
  index: '$SPX',
  sort: 'PERCENT_CHANGE_DOWN'
};

const spxMovers = await getMovers(config);
```
<details>
  <summary>Example response shape</summary>

```typescript
[
  {
    description: 'NVIDIA CORP',
    volume: 188505454,
    lastPrice: 177.82,
    netChange: -5.52,
    marketShare: 5.66,
    totalVolume: 3333261323,
    trades: 1869180,
    netPercentChange: -0.0301,
    symbol: 'NVDA'
  },
  // ...
  {
    description: 'APPLE INC',
    volume: 41094448,
    lastPrice: 257.46,
    netChange: -2.83,
    marketShare: 1.23,
    totalVolume: 3333261323,
    trades: 451157,
    netPercentChange: -0.0109,
    symbol: 'AAPL'
  }
]
```  

</details>

### `getMarketHours()` - Market hours for one or more markets

```typescript
import { getMarketHours, GetMarketHoursConfig } from "@misterpea/schwab-node";

const config: GetMarketHoursConfig = {
  markets: ['equity', 'option'],
  date: '2026-03-11'
};

const hours = await getMarketHours(config);
```

<details>
  <summary>Example response shape</summary>

  ```typescript
  [
    {
      "date": "2026-03-11",
      "marketType": "EQUITY",
      "isOpen": true,
      "sessionHours": {
      "preMarket": [
        {
        "start": "2026-03-11T07:00:00-04:00",
        "end": "2026-03-11T09:30:00-04:00"
        }
      ],
      "regularMarket": [
        {
        "start": "2026-03-11T09:30:00-04:00",
        "end": "2026-03-11T16:00:00-04:00"
        }
      ],
      "postMarket": [
        {
        "start": "2026-03-11T16:00:00-04:00",
        "end": "2026-03-11T20:00:00-04:00"
        }
      ]
      }
    },
    {
      "date": "2026-03-11",
      "marketType": "OPTION",
      "isOpen": true,
      "sessionHours": {
      "regularMarket": [
        {
        "start": "2026-03-11T09:30:00-04:00",
        "end": "2026-03-11T16:00:00-04:00"
        }
      ]
    }
  }
]
```

</details>

### `getOptionChain()` - Option chain keyed by expiration and strike

```typescript
import { getOptionChain, GetOptionChainRequest } from "@misterpea/schwab-node";

const config: GetOptionChainRequest = { 
  symbol: 'AAPL',
  contractType: 'CALL',
  strikeCount: 2,
  fromDate: '2026-03-09',
  toDate: '2026-03-10'
};

const optionChain = await getOptionChain(config);
```

<details>
  <summary>Example response shape:</summary>

```typescript
{
 "symbol": "AAPL",
 "status": "SUCCESS",
 "underlying": null,
 "strategy": "SINGLE",
 "interval": 0,
 "isDelayed": false,
 "isIndex": false,
 "interestRate": 3.568,
 "underlyingPrice": 257.35,
 "volatility": 29,
 "daysToExpiration": 3,
 "dividendYield": 0.404,
 "numberOfContracts": 2,
 "assetMainType": "EQUITY",
 "assetSubType": "COE",
 "isChainTruncated": false,
 "callExpDateMap": {
  "2026-03-09:3": {
   "255.0": [
    {
     "putCall": "CALL",
     "symbol": "AAPL  260309C00255000",
     "description": "AAPL 03/09/2026 255.00 C",
     "exchangeName": "OPR",
     "bid": 3.6,
     "ask": 3.75,
     "last": 3.8,
     "mark": 3.68,
     "bidSize": 314,
     "askSize": 142,
     "bidAskSize": "314X142",
     "lastSize": 1,
     "highPrice": 5.15,
     "lowPrice": 2.65,
     "openPrice": 0,
     "closePrice": 6.45,
     "totalVolume": 4645,
     "tradeTimeInLong": 1772820843311,
     "quoteTimeInLong": 1772820866695,
     "netChange": -2.65,
     "percentChange": -41.08,
     "volatility": 24.142,
     "delta": 0.664,
     "gamma": 0.064,
     "theta": -0.351,
     "vega": 0.086,
     "rho": 0.013,
     "openInterest": 94,
     "timeValue": 1.45,
     "intrinsicValue": 2.35,
     "extrinsicValue": 1.45,
     "theoreticalOptionValue": 3.621,
     "theoreticalVolatility": 29,
     "optionDeliverablesList": [
      {
       "symbol": "AAPL",
       "deliverableUnits": 100,
       "assetType": "STOCK",
       "currencyType": null
      }
     ],
     "strikePrice": 255,
     "expirationDate": "2026-03-09T20:00:00.000+00:00",
     "daysToExpiration": 3,
     "expirationType": "W",
     "lastTradingDay": 1773100800000,
     "multiplier": 100,
     "settlementType": "P",
     "deliverableNote": "100 AAPL",
     "markChange": -2.78,
     "markPercentChange": -43.02,
     "optionRoot": "AAPL",
     "exerciseType": "A",
     "high52Week": 18,
     "low52Week": 2.65,
     "inTheMoney": true,
     "mini": false,
     "pennyPilot": true,
     "nonStandard": false
    }
   ],
   "257.5": [
    {
     "putCall": "CALL",
     "symbol": "AAPL  260309C00257500",
     "description": "AAPL 03/09/2026 257.50 C",
     "exchangeName": "OPR",
     "bid": 2.06,
     "ask": 2.11,
     "last": 2.2,
     "mark": 2.09,
     "bidSize": 64,
     "askSize": 15,
     "bidAskSize": "64X15",
     "lastSize": 1,
     "highPrice": 3.55,
     "lowPrice": 1.58,
     "openPrice": 0,
     "closePrice": 4.52,
     "totalVolume": 10862,
     "tradeTimeInLong": 1772820836068,
     "quoteTimeInLong": 1772820866694,
     "netChange": -2.32,
     "percentChange": -51.33,
     "volatility": 23.148,
     "delta": 0.492,
     "gamma": 0.073,
     "theta": -0.379,
     "vega": 0.094,
     "rho": 0.01,
     "openInterest": 2060,
     "timeValue": 2.2,
     "intrinsicValue": -0.15,
     "extrinsicValue": 2.35,
     "theoreticalOptionValue": 2.1,
     "theoreticalVolatility": 29,
     "optionDeliverablesList": [
      {
       "symbol": "AAPL",
       "deliverableUnits": 100,
       "assetType": "STOCK",
       "currencyType": null
      }
     ],
     "strikePrice": 257.5,
     "expirationDate": "2026-03-09T20:00:00.000+00:00",
     "daysToExpiration": 3,
     "expirationType": "W",
     "lastTradingDay": 1773100800000,
     "multiplier": 100,
     "settlementType": "P",
     "deliverableNote": "100 AAPL",
     "markChange": -2.43,
     "markPercentChange": -53.87,
     "optionRoot": "AAPL",
     "exerciseType": "A",
     "high52Week": 17.5,
     "low52Week": 1.58,
     "inTheMoney": false,
     "mini": false,
     "pennyPilot": true,
     "nonStandard": false
    }
   ]
  }
 },
 "putExpDateMap": {}
}

```

</details>

### `getAtmOptionData()` - ATM options (Δ ≈ ±0.5) in an inclusive DTE window

```typescript
import { getAtmOptionData, GetAtmOptionRequest } from "@misterpea/schwab-node";

const config: GetAtmOptionRequest = {
  symbol: "AAPL",
  // 7 to 21 days inclusive
  window: [7, 21],
};

const atmData = await getAtmOptionData(config);
```

<details>
  <summary>Example response shape</summary>

```typescript
[
  {
    put_call: 'CALL',
    day_of_expiry: 'FRI',
    underlying: 'AAPL',
    bid: 4.3,
    ask: 4.85,
    bidAskSpreadPct: 12.790697674418603,
    open_interest: 586,
    total_volume: 3267,
    symbol: 'AAPL  260313C00257500',
    dte: 7,
    theta: -0.339,
    strike_price: 257.5,
    gamma: 0.034,
    volatility: 33.279,
    vega: 0.141,
    delta: 0.501,
    rho: 0.023
  },
  // ...
  {
    put_call: 'PUT',
    day_of_expiry: 'FRI',
    underlying: 'AAPL',
    bid: 6.3,
    ask: 6.5,
    bidAskSpreadPct: 3.174603174603177,
    open_interest: 1414,
    total_volume: 802,
    symbol: 'AAPL  260327P00255000',
    dte: 21,
    theta: -0.185,
    strike_price: 255,
    gamma: 0.021,
    volatility: 30.416,
    vega: 0.243,
    delta: -0.439,
    rho: -0.068
  }
]
```  

</details>

### `greekFilter()` - Options filtered by DTE and Greek ranges

```typescript
import { greekFilter, GreekFilterRequest } from "@misterpea/schwab-node";

const config: GreekFilterRequest = {
  symbol: "GILD",
  window: [14, 21],
  greek: {
    iv: [29, 30],
    vega: [0.05, 0.15],
    absDelta:[0.35, 0.49]
  },
};

const filterGreeks = await greekFilter(config);
```

<details>
  <summary>Example response shape</summary>

  ```typescript
  [
    {
      put_call: 'CALL',
      day_of_expiry: 'THR',
      underlying: 'GILD',
      bid: 2.59,
      ask: 3.1,
      bidAskSpreadPct: 19.691119691119702,
      open_interest: 26,
      total_volume: 34,
      symbol: 'GILD  260320C00144000',
      dte: 14,
      theta: -0.092,
      strike_price: 144,
      gamma: 0.051,
      volatility: 29.438,
      vega: 0.11,
      delta: 0.471,
      rho: 0.021
    },
    // ...
    {
      put_call: 'PUT',
      day_of_expiry: 'THR',
      underlying: 'GILD',
      bid: 3.55,
      ask: 4.3,
      bidAskSpreadPct: 21.126760563380284,
      open_interest: 6,
      total_volume: 1,
      symbol: 'GILD  260327P00143000',
      dte: 21,
      theta: -0.115,
      strike_price: 143,
      gamma: 0.039,
      volatility: 29.346,
      vega: 0.136,
      delta: -0.477,
      rho: -0.041
    }
]

```
</details>

## Account Endpoints

### `getAccounts()` - Info on accounts, including balances and buying power
```typescript
const acctInfo = await getAccounts();
```

<details>
  <summary>Example response shape</summary>

```typescript
[
 {
  "securitiesAccount": {
   "type": "MARGIN",
   "accountNumber": "12345678",
   "roundTrips": 0,
   "isDayTrader": true,
   "isClosingOnlyRestricted": false,
   "pfcbFlag": false,
   "initialBalances": {
    "accruedInterest": 0,
    "availableFundsNonMarginableTrade": 100000,
    "bondValue": 100000,
    "buyingPower": 100000,
    "cashBalance": 100000.5,
    "cashAvailableForTrading": 0,
    "cashReceipts": 0,
    "dayTradingBuyingPower": 100000,
    "dayTradingBuyingPowerCall": 0,
    "dayTradingEquityCall": 0,
    "equity": 100000.99,
    "equityPercentage": 100,
    "liquidationValue": 100000.99,
    "longMarginValue": 100000,
    "longOptionMarketValue": 0,
    "longStockValue": 100000,
    "maintenanceCall": 0,
    "maintenanceRequirement": 100000,
    "margin": 100000.5,
    "marginEquity": 100000.99,
    "moneyMarketFund": 0,
    "mutualFundValue": 100000,
    "regTCall": 0,
    "shortMarginValue": 0,
    "shortOptionMarketValue": 0,
    "shortStockValue": 0,
    "totalCash": 0,
    "isInCall": false,
    "pendingDeposits": 0,
    "marginBalance": 0,
    "shortBalance": 0,
    "accountValue": 100000.99
   },
   "currentBalances": {
    "accruedInterest": 0,
    "cashBalance": 100000.5,
    "cashReceipts": 0,
    "longOptionMarketValue": 0,
    "liquidationValue": 100000.75,
    "longMarketValue": 100000,
    "moneyMarketFund": 0,
    "savings": 0,
    "shortMarketValue": 0,
    "pendingDeposits": 0,
    "mutualFundValue": 0,
    "bondValue": 0,
    "shortOptionMarketValue": 0,
    "availableFunds": 100000,
    "availableFundsNonMarginableTrade": 100000,
    "buyingPower": 100000,
    "buyingPowerNonMarginableTrade": 100000,
    "dayTradingBuyingPower": 100000,
    "equity": 100000.75,
    "equityPercentage": 100,
    "longMarginValue": 100000,
    "maintenanceCall": 0,
    "maintenanceRequirement": 100000,
    "marginBalance": 0,
    "regTCall": 0,
    "shortBalance": 0,
    "shortMarginValue": 0,
    "sma": 100000
   },
   "projectedBalances": {
    "availableFunds": 100000,
    "availableFundsNonMarginableTrade": 100000,
    "buyingPower": 100000,
    "dayTradingBuyingPower": 100000,
    "dayTradingBuyingPowerCall": 0,
    "maintenanceCall": 0,
    "regTCall": 0,
    "isInCall": false,
    "stockBuyingPower": 100000
   }
  },
  "aggregatedBalance": {
   "currentLiquidationValue": 100000.75,
   "liquidationValue": 100000.75
  }
 }
]

```
</details>

### `getAccountNumbers()` - List of account numbers and their encrypted values
```typescript
const acctNums = await getAccountNumbers();
```
<details>
  <summary>Example response shape</summary>
  
  ```typescript
[
 {
  "accountNumber": "12345678",
  "hashValue": "0123456789ABCDEFGH01234567890123456789ABCDEFGH0123456789"
 }
]

  ```
</details>

### `getUserPreference()` - Accounts and streamer info
<details>
<summary>Example response shape</summary>

```typescript
{
 "accounts": [
  {
   "accountNumber": "12345678",
   "primaryAccount": false,
   "type": "BROKERAGE",
   "nickName": "Main Account",
   "accountColor": "Green",
   "displayAcctId": "...678",
   "autoPositionEffect": true
  }
 ],
 "streamerInfo": [
  {
   "streamerSocketUrl": "wss://streamer-api.schwab.url/websocket",
   "schwabClientCustomerId": "0123456789ABCDEFGH01234567890123456789ABCDEFGH0123456789",
   "schwabClientCorrelId": "0123456789ABCDEFGH01234567890123456789ABCDEFGH0123456789",
   "schwabClientChannel": "A1",
   "schwabClientFunctionId": "APIAPP"
  }
 ],
 "offers": [
  {
   "level2Permissions": true,
   "mktDataPermission": "NP"
  }
 ]
}
```
</details>

<details>
<summary>Explicit Auth</summary>

Most users do not need to instantiate `SchwabAuth` directly. Authenticated requests load default auth from `.env`.

Use an explicit auth client when you want direct control over the token lifecycle:

```typescript
import { SchwabAuth } from "@misterpea/schwab-node";

process.loadEnvFile(".env");

function reqEnv(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing env var ${name}`);
  return value;
}

const auth = new SchwabAuth({
  clientId: reqEnv("SCHWAB_CLIENT_ID"),
  clientSecret: reqEnv("SCHWAB_CLIENT_SECRET"),
  redirectUri: reqEnv("SCHWAB_REDIRECT_URI"),
});

const tokenInfo = await auth.getAuth();
```

Token shape:

```json
{
  "expires_in": 1800,
  "token_type": "Bearer",
  "scope": "api",
  "refresh_token": "bbbbbb-aaaaaa-zzzzzzz_yyyyyyy-xxxxx@",
  "access_token": "I0.aaaaaa.bbbbbb_cccccc@",
  "id_token": "abcdefghijklmnopqrstuvwxyz.abcdefghijklmnopqrstuvwxyz.abcdefghijklm-nopqrstuvwxyz",
  "obtained_at": 946684800000,
  "refresh_obtained_at": 946684800000
}
```
</details>

## Streaming

The WebSocket streamer uses [ZeroMQ](https://zeromq.org/$0) to handle message delivery. This allows users to consume the streaming data with components built in any language that has ZeroMQ bindings.

__Note: ZeroMQ is running on `tcp://localhost:5555`__

<br />

The streaming system is constructed in 2 layers:    
- __Socket layer__ - messages from/to Schwab's websocket (this is where your subscriptions are sent)
- __Broadcast layer (zmq)__ - messages from the socket layer (this is where you plug in)

__Raw usage:__

```typescript
import { SchwabStreamer } from "@misterpea/schwab-node";

const streamer = new SchwabStreamer();

await streamer.connect();
await streamer.login();

await streamer.subsL1Futures({
  keys: ["/ESH26"],
  fields: [
    "symbol",
    "bidPrice",
    "askPrice",
    "lastPrice",
    "totalVolume",
    "quoteTime",
  ],
});

```

Semantic futures usage:

```typescript
import {
  LEVELONE_FUTURES_FIELDS,
  SchwabStreamer,
} from "@misterpea/schwab-node";

const streamer = new SchwabStreamer();

await streamer.connect();
await streamer.login();

await streamer.subsL1Futures({
  keys: ["/ESH26"],
  fields: [
    "symbol",
    "bidPrice",
    "askPrice",
    "lastPrice",
    "totalVolume",
    "quoteTime",
  ],
});

console.log(LEVELONE_FUTURES_FIELDS["10"]); // "quoteTime"
```

Semantic equities usage:

```typescript
await streamer.subsL1Equities({
  keys: ["AAPL"],
  fields: ["symbol", "bidPrice", "askPrice", "lastPrice", "quoteTime"],
});
```

Semantic options usage:

```typescript
await streamer.subsL1Options({
  keys: ["AAPL  251219C00200000"],
  fields: ["symbol", "bidPrice", "askPrice", "lastPrice", "quoteTime"],
});
```

Semantic futures options usage:

```typescript
await streamer.subsL1FuturesOptions({
  keys: ["./OZCZ23C565"],
  fields: ["symbol", "bidPrice", "askPrice", "lastPrice", "quoteTime"],
});
```

Semantic forex usage:

```typescript
await streamer.subsL1Forex({
  keys: ["EUR/USD"],
  fields: ["symbol", "bidPrice", "askPrice", "lastPrice", "quoteTime"],
});
```

Level 2 NYSE book usage:

```typescript
await streamer.subsL2NyseBook({
  keys: ["JPM"],
  fields: ["symbol", "marketSnapshotTime", "bidSideLevels", "askSideLevels"],
});
```

`NASDAQ_BOOK` and `OPTIONS_BOOK` use the same top-level field names through `subsL2NasdaqBook` and `subsL2OptionsBook`.

Chart equity usage:

```typescript
await streamer.subsChartEquity({
  keys: ["AAPL"],
  fields: ["symbol", "openPrice", "highPrice", "lowPrice", "closePrice", "volume", "chartTime"],
});
```

Screener equity usage:

```typescript
await streamer.subsScreenerEquity({
  keys: ["NYSE_VOLUME_0"],
  fields: ["symbol", "timestamp", "sortField", "frequency", "items"],
});
```

Account activity usage:

```typescript
await streamer.subsAcctActivity({
  keys: ["CLIENT_KEY"],
  fields: ["subscriptionKey"],
});
```

For book payload adapters, the package also exports `BOOK_FIELDS`, `BOOK_PRICE_LEVEL_FIELDS`, and `BOOK_MARKET_MAKER_FIELDS` so the nested Level 2 structure can be resolved without hard-coding field positions.

The exported `CHART_EQUITY_FIELDS`, `CHART_FUTURES_FIELDS`, `SCREENER_FIELDS`, `ACCT_ACTIVITY_FIELDS`, the Level 1 field maps, their inverse maps, and the resolver helpers can also be reused when you build adapters on top of the raw streamer payloads.

## Feedback & Requests

Found a bug or have a feature request?  
Please open an issue using the Issue Form:  
https://github.com/MisterPea/schwab-node/issues/new/choose

## AI Assistance Disclosure

AI tooling (OpenAI Codex) was used as a development assistant for:

- Identifying potential bugs and edge cases
- Strengthening the authentication flow
- Assisting with test development and validation

All core architecture, implementation, and final code decisions were written and reviewed by the project author.

***
